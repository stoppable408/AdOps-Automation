from modules.TraffickingObject import TraffickingObject
from retrying import retry

class Placement(TraffickingObject):
    
    @retry(wait_exponential_multiplier=10, wait_exponential_max=100) 
    def __init__(self, searchString, eventLoop=None, session=None):
        super().__init__()
#        print("getting placement {0}".format(searchString))
        if hasattr(self, "session"):
            session = self.session
        self.get_body(searchString,eventLoop, session).correctDate()
        if eventLoop != None:
             self.eventLoop = eventLoop
        
    
    @retry(wait_exponential_multiplier=10, wait_exponential_max=100)     
    def getAdList(self):
        self.url = "https://www.googleapis.com/dfareporting/v2.8/userprofiles/{profile_id}/ads?placementIds={placementId}".format(profile_id=self.profile_id,placementId=self.body["id"])
        async def wait():
            async with self.session.get(self.url, headers=self.auth) as r:
                text = await r.text()
                if r.status == 200:
                    response = self.json.loads(text)["ads"]
                    self.ads = response
                else:
                    self.handleError(text)
        if self.eventLoop == None:
            self.eventLoop = self.asyncio.get_event_loop()
            self.eventLoop.run_until_complete(wait())
            self.eventLoop.close()
            self.eventLoop = None
        else:
            adEvent = self.eventLoop.create_task(wait())
            self.eventLoop.run_until_complete(adEvent)
        return self
        
    @retry(wait_exponential_multiplier=10, wait_exponential_max=100)     
    def pushStaticClickTracking(self):
        self.url = "https://www.googleapis.com/dfareporting/v2.8/userprofiles/{profile_id}/placements?id={placementId}".format(profile_id=self.profile_id,placementId=self.body["id"])
        payload = {"tagSetting":{"includeClickThroughUrls": True,}}
        payloadText = '"includeClickThroughUrls": true'
        async def wait():
            async with self.session.patch(self.url, headers=self.auth, data=self.json.dumps(payload)) as r:
                text = await r.text()
                if r.status == 200:
                    response = self.json.loads(text)
                    if payloadText in response:
                        print("{0} updated successfully".format(self.body['name']))
                else:
                    print("{0} failed to update.".format(self.body['name']))
                    self.handleError(text)
        if self.eventLoop == None:
            self.eventLoop = self.asyncio.get_event_loop()
            self.eventLoop.run_until_complete(wait())
        else:
            changeLogEvent = self.eventLoop.create_task(wait())
            self.eventLoop.run_until_complete(changeLogEvent)
        return self
    @retry(wait_exponential_multiplier=10, wait_exponential_max=100)      
    def correctDate(self):
        async def wait():
            async with self.session.get(self.url, headers=self.auth) as r:
                text = await r.text()
                if r.status == 200:
                    placementGroup = self.json.loads(text)
                    self.body["pricingSchedule"]["startDate"] = placementGroup["startDate"]
                    self.body["pricingSchedule"]["endDate"] = placementGroup["endDate"]
                else:
                    self.handleError(text)
        
        try:
            self.body["placementGroupId"]
            self.url = "https://www.googleapis.com/dfareporting/v2.8/userprofiles/{profile_id}/placementGroups/{PGID}".format(profile_id=self.profile_id,PGID=self.body["placementGroupId"])
            if self.eventLoop == None:
                self.eventLoop = self.asyncio.get_event_loop()
                self.eventLoop.run_until_complete(wait())
                self.eventLoop.close()
                self.eventLoop = None
            else:
                adEvent = self.eventLoop.create_task(wait())
                self.eventLoop.run_until_complete(adEvent)
        except:
            pass
        return self
    
    def listByCampaign(self, campaignID,separateByDimension=None):
        self.url = "https://www.googleapis.com/dfareporting/v3.0/userprofiles/{profileId}/placements?campaignId={campaignID}".format(profileId=self.profile_id,campaignID=str(campaignID))
        async def wait():
            async with self.session.get(self.url, headers=self.auth) as r:
                text = await r.text()
                if r.status == 200:
                    if separateByDimension != None:
                        response = [x for x in self.json.loads(text)["placements"] if separateByDimension in x["name"]]
                    else:
                        response = self.json.loads(text)["placements"]
                        
                    self.placementList = response
                else:
                    self.handleError(text)
        if self.eventLoop == None:
            self.eventLoop = self.asyncio.get_event_loop()
            self.eventLoop.run_until_complete(wait())
            self.eventLoop.close()
            self.eventLoop = None
        else:
            placementEvent = self.eventLoop.create_task(wait())
            self.eventLoop.run_until_complete(placementEvent)
        return self
        
    def isTrafficked(self):
        import datetime
        from modules.Ad import Ad
        from modules.Creative import Creative
        currentMonth = datetime.datetime.now().strftime("%B").lower()
        currentDate = datetime.datetime.now()
        def checkDate(dateString):
            return datetime.datetime.strptime(dateString, "%Y-%m-%dT%H:%M:%S.000Z") > currentDate
        def checkSession(session, initialSession):
            if initialSession != session:
                return session
            else:
                return initialSession
        initialSession = self.session
        initialEventLoop = self.eventLoop
        self.getAdList()

        response = [x for x in self.ads if "Brand-neutral" not in x['name'] and "TRACKING" not in x["name"] and x["active"] == True and "AD_SERVING_DEFAULT_AD" not in x["type"] and checkDate(x["endTime"])]
        self.response = response
        self.ads = [{"id":x["id"]} for x in response]
        if not self.ads:
            self.trafficked = False
            self.creativeName = "Not Trafficked"
            self.creativeDate = "Not Trafficked"
            return self
        for adBody in self.ads:
            ad = Ad(adBody["id"],initialEventLoop, initialSession)
            initialSession = checkSession(ad.session, initialSession)
            try:
                creativeAssignments = ad.body["creativeRotation"]["creativeAssignments"]
            except:
                continue
            for creative in creativeAssignments:
                creativeID = creative["creativeId"]
                creativeElement = Creative(creativeID,initialEventLoop, initialSession)
                initialSession = checkSession(creativeElement.session, initialSession)
                creativeName = creativeElement.body["name"]

                if currentMonth in creativeName.lower():
                    self.trafficked = True
                    self.creativeName = creativeName
                    timestamp = int(creativeElement.body["lastModifiedInfo"]["time"]) / 1e3
                    self.creativeDate = datetime.datetime.fromtimestamp(timestamp).strftime('%m/%d/%y %I:%M %p')
                    return self
                else:
                    self.trafficked = False
                    self.creativeName = creativeName
                    timestamp = int(creativeElement.body["lastModifiedInfo"]["time"]) / 1e3
                    self.creativeDate = datetime.datetime.fromtimestamp(timestamp).strftime('%m/%d/%y %I:%M %p')

        return self
    def __str__(self):
        return "placements"