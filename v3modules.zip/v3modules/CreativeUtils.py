

def getCreative(Api, CreativeId):
    print(Api)
    creative = Api.generateRequestUrl("creatives",objectId=CreativeId).get().response
    return creative
