from v3modules.DCMAPI import DCMAPI




    # from modules import send_mail
    # import os
    # directories = os.listdir()
    # reports = [x for x in directories if "Placement" in x]
    # for report in reports:
    #     send_mail.send_email(report, title="LMA SS Placements",recipients=["Lennon.Turner@amnetgroup.com","Kristine.Gillette@carat.com","Holly.Champoux@carat.com","Ali.Ciaffone@carat.com"])
